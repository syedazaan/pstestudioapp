import React from 'react';
import {Stylesheet, View, Text} from 'react-native';

export default class pqr extends React.Component{
        render(){

        }    
}