import React from 'react';
import { StyleSheet, View, Text } from 'react-native';

export default class abc extends React.Component{
        render(){
                return(
                        <View>
                                <View>

                                </View>
                        </View>
                );          
        }        
}